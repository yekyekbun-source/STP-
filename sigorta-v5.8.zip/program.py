# -- coding: utf-8 --
"""
Osman Örs Sigorta Takip v5.7 (QR Görseli Panodan)
- "QR Kod Görsel Oku": WhatsApp/ruhsat görselini panodan alıp QR okur (dosya seçtirmez)
- "Görsel Yapıştır (OCR)" aynı şekilde panodan görselden metin OCR yapar
- PDF/QR/CSV/HTML, otomatik tarih & kalan gün hesapları korunmuştur
"""

import os, re, json, csv, shutil, webbrowser, datetime, io, unicodedata
from typing import Optional, Dict, List

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
# EKLENEN: Demo süresi kontrolü ve güncelleme
from demo_check import is_demo_expired
from updater import check_for_update

# ---- (opsiyonel) PDF/QR/OCR kütüphaneleri ----
try: import fitz  # PyMuPDF
except Exception: fitz = None
try: import pdfplumber
except Exception: pdfplumber = None
try:
    from PyPDF2 import PdfReader
except Exception:
    PdfReader = None
try: from pdf2image import convert_from_path
except Exception: convert_from_path = None
try: import pytesseract
except Exception: pytesseract = None
try:
    from PIL import Image, ImageGrab
except Exception:
    Image = None
    ImageGrab = None

QR_PYZBAR = False
try:
    from pyzbar.pyzbar import decode as qr_decode
    QR_PYZBAR = True
except Exception: pass

QR_CV = False
try:
    import cv2
    QR_CV = True
except Exception: cv2 = None

APP_TITLE = "Osman Örs Sigorta Takip v5.7 (Panodan QR & OCR)"
DATA_FILE = "kayitlar.json"
POLICE_DIR = "poliseler"
DATE_FMT = "%d.%m.%Y"

POLICE_TURLERI = ["Trafik", "Kasko", "DASK", "Konut", "İşyeri", "Sağlık", "Nakliyat", "Sorumluluk", "TSS", "Diğer"]

# form alanları
FIELDS = [
    "Ad Soyad", "T.C.", "Doğum Tarihi", "Plaka", "Belge Seri No", "UVAT Kodu",
    "Poliçe Türü", "Poliçe No", "Acente", "Şirket",
    "Başlangıç", "Bitiş", "Kalan Gün", "Poliçe Dosyası"
]

# tablo sütunları (ekran)
DISPLAY_COLS = [
    "No", "Ad Soyad", "Doğum Tarihi", "T.C.", "Plaka", "Belge Seri No",
    "Başlangıç", "Bitiş", "Kalan Gün", "Şirket", "Acente",
    "UVAT Kodu", "Poliçe Türü", "Poliçe No", "Poliçe Dosyası"
]
COL_WIDTHS = {
    "No": 48, "Ad Soyad": 140, "Doğum Tarihi": 100, "T.C.": 118, "Plaka": 112, "Belge Seri No": 120,
    "Başlangıç": 110, "Bitiş": 110, "Kalan Gün": 74, "Şirket": 130, "Acente": 150,
    "UVAT Kodu": 96, "Poliçe Türü": 110, "Poliçe No": 130, "Poliçe Dosyası": 220
}

# -------------- yardımcılar --------------
def ensure_dirs(): os.makedirs(POLICE_DIR, exist_ok=True)

def safe_load():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, list) else []
        except Exception:
            return []
    return []

def safe_save(rows):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

def fmt_date(d: Optional[datetime.date]) -> str:
    return d.strftime(DATE_FMT) if d else ""

TR_MONTHS = {
    "ocak": 1, "subat": 2, "şubat": 2, "mart": 3, "nisan": 4, "mayis": 5, "mayıs": 5,
    "haziran": 6, "temmuz": 7, "agustos": 8, "ağustos": 8, "eylul": 9, "eylül": 9,
    "ekim": 10, "kasim": 11, "kasım": 11, "aralik": 12, "aralık": 12,
    "oca": 1, "sub": 2, "şub": 2, "mar": 3, "nis": 4, "may": 5, "haz": 6, "tem": 7,
    "agu": 8, "ağu": 8, "eyl": 9, "eki": 10, "kas": 11, "ara": 12
}

def mkdate(y, m, d):
    try:
        return fmt_date(datetime.date(int(y), int(m), int(d)))
    except Exception:
        return None

def strip_time(s: str) -> str:
    return re.sub(r"\s+\d{1,2}:\d{2}(:\d{2})?$", "", s.strip())

def parse_date_any(s: str) -> Optional[str]:
    s = strip_time(s)
    m = re.match(r"^\s*(\d{4})[-./](\d{1,2})[-./](\d{1,2})\s*$", s)
    if m:
        return mkdate(m.group(1), m.group(2), m.group(3))
    m = re.match(r"^\s*(\d{1,2})[-./](\d{1,2})[-./](\d{2,4})\s*$", s)
    if m:
        d, mo, y = m.group(1), m.group(2), m.group(3)
        y = "20" + y if len(y) == 2 else y
        return mkdate(y, mo, d)
    m = re.match(r"^\s*(\d{1,2})\s+([A-Za-zÇĞİÖŞÜçğıöşü\.]+)\s+(\d{2,4})\s*$", s)
    if m:
        d = m.group(1)
        mo = _norm_key(m.group(2)).strip(".")
        mo = TR_MONTHS.get(mo)
        if mo:
            y = m.group(3)
            y = "20" + y if len(y) == 2 else y
            return mkdate(y, mo, d)
    return None

def parse_date_str(s: str) -> Optional[datetime.date]:
    if not s:
        return None
    nd = parse_date_any(s)
    if nd:
        try:
            return datetime.datetime.strptime(nd, DATE_FMT).date()
        except Exception:
            return None
    try:
        return datetime.datetime.strptime(strip_time(s).replace("/", "."), DATE_FMT).date()
    except Exception:
        return None

def add_365(bas: str) -> str:
    d = parse_date_str(bas)
    return fmt_date(d + datetime.timedelta(days=365)) if d else ""

def kalan_gun(bitis: str) -> Optional[int]:
    d = parse_date_str(bitis)
    return (d - datetime.date.today()).days if d else None

def renk_kodu(kg):
    if kg is None:
        return "white"
    if kg <= 3:
        return "tomato"
    if kg <= 14:
        return "khaki"
    return "white"

def copy_policy_file(src, rec):
    if not src or not os.path.isfile(src):
        return rec.get("Poliçe Dosyası", "")
    ensure_dirs()
    pol = (rec.get("Poliçe No", "") or "police").replace("/", "-").replace("\\", "-")
    plk = (rec.get("Plaka", "") or "plaka").replace(" ", "")
    dst = os.path.join(POLICE_DIR, f"{pol}{plk}{os.path.basename(src)}")
    try:
        shutil.copy2(src, dst)
        return dst
    except Exception:
        return rec.get("Poliçe Dosyası", "")

# desenler
PLAKA_RE = re.compile(r"\b(\d{1,3})\s*([A-ZÇĞİÖŞÜ]{1,4})\s*(\d{1,5})\b")
DATE_ANY = re.compile(r"\b(\d{1,2}[./-]\d{1,2}[./-]\d{2,4}|\d{4}[./-]\d{1,2}[./-]\d{1,2}|\d{1,2}\s+[A-Za-zÇĞİÖŞÜçğıöşü\.]+\s+\d{2,4})\b", re.IGNORECASE)

POLNO_PATTERNS = [
    r"(?:POL[İI]ÇE|POL[İI]CE|POLICY|POLICE)\s*(?:NO|NUMARASI|NUM|#)?\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-\/\.]{5,})",
    r"\bPOL[İI]ÇE\s*NO\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-\/\.]{5,})",
    r"\bPOL\s*NO\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-\/\.]{5,})",
    r"\b(?:No|NO)\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-\/\.]{7,})\b"
]

SIGORTALI_HINTS = [
    re.compile(r"^\s*Sigortal[ıi]\s*[:\-]?\s*(.+)$", re.IGNORECASE),
    re.compile(r"^\s*Sigorta\s*Ettiren(?:in)?\s*[:\-]?\s*(.+)$", re.IGNORECASE),
    re.compile(r"^\s*Ad[ıi]\s*Soyad[ıi]\s*[:\-]?\s*(.+)$", re.IGNORECASE),
    re.compile(r"^\s*Sigortal[ıi]\s*/\s*Sigorta\s*Ettiren\s*[:\-]?\s*(.+)$", re.IGNORECASE),
    re.compile(r"^\s*ADI(?:\s*VE)?\s*SOYADI\s*[:\-]?\s*(.+)$", re.IGNORECASE),
]

PLAKA_HINT = re.compile(r"(Plaka|Ara[çc] Plakas[ıi]|Arac[ıi]n Plakas[ıi])", re.IGNORECASE)
BAS_HINT = re.compile(r"(Başlang[ıi]ç|Tanzim|Düzenleme(?:\s*Tarihi)?|Baş Tar)", re.IGNORECASE)
BITIS_HINT = re.compile(r"(Bitiş|Vade ?Sonu?|Vade Bitiş[iı]|Son Tarih[iı])", re.IGNORECASE)
DOGUM_HINT = re.compile(r"(Doğum\s*Tarihi|D\.?T\.?)", re.IGNORECASE)

def _normalize_plate(s: str) -> str:
    s = s.upper().replace('-', ' ').replace('.', ' ')
    s = re.sub(r'\s+', ' ', s.strip())
    m = PLAKA_RE.search(s)
    if m:
        return f"{m.group(1)} {m.group(2)} {m.group(3)}"
    if re.match(r'^\d{1,3}\s*[A-Z]', s):
        parts = re.findall(r'\d+|[A-Z]+', s)
        if len(parts) >= 3:
            return f"{parts[0]} {parts[1]} {parts[2]}"
    return s

def _looks_like_name(s: str) -> bool:
    s = re.sub(r"[,:;|]+.*$", "", s).strip()
    words = [w for w in re.split(r"\s+", s) if w]
    if len(words) < 2 or len(s) > 64:
        return False
    letters = sum(c.isalpha() for c in s)
    digits = sum(c.isdigit() for c in s)
    bad = {"unvan", "ünvan", "acente", "şirket", "company", "insurer", "poliçe", "sigorta", "vergi", "kimlik", "tc", "no", "iletişim", "adres", "malatya", "yesilyurt", "yesilyur", "gsm", "e-mail", "email", "bilgisi"}
    if any(b in s.lower() for b in bad):
        return False
    return letters >= digits and letters > 0

def _clean_name(s: str) -> str:
    s = re.sub(r"[,:;|]+.*$", "", s).strip()
    s = re.sub(r'\s*(MALATYA|YESİLYURT|YEŞİLYURT|İSTANBUL|ANKARA|İZMİR|GSM|E-MAIL|EMAIL|BİLGİSİ).*$', '', s, flags=re.IGNORECASE)
    s = re.sub(r'\s{2,}', ' ', s)
    return s.strip()

def _norm_key(s: str) -> str:
    s = s.strip().lower()
    s = s.replace("ı", "i").replace("ğ", "g").replace("ş", "s").replace("ç", "c").replace("ö", "o").replace("ü", "u")
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[^a-z0-9\s\.\/-]", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s

def _find_near_date(lines: List[str], hint: re.Pattern) -> Optional[str]:
    for i, ln in enumerate(lines):
        if hint.search(ln):
            m = DATE_ANY.search(ln) or (DATE_ANY.search(lines[i + 1]) if i + 1 < len(lines) else None)
            if m:
                nd = parse_date_any(m.group(1))
                if nd:
                    return nd
    return None

def _find_birth_date(lines: List[str]) -> Optional[str]:
    for i, ln in enumerate(lines):
        if DOGUM_HINT.search(ln):
            m = DATE_ANY.search(ln) or (DATE_ANY.search(lines[i + 1]) if i + 1 < len(lines) else None)
            if m:
                nd = parse_date_any(m.group(1))
                if nd:
                    return nd
    return None

def _find_plate(lines: List[str], full_text: str) -> Optional[str]:
    for i, ln in enumerate(lines):
        if PLAKA_HINT.search(ln):
            parts = re.split(r'[:]', ln, maxsplit=1)
            if len(parts) > 1:
                cand = _normalize_plate(parts[1])
                if cand:
                    return cand
            for j in (1, 2):
                if i + j < len(lines):
                    cand = _normalize_plate(lines[i + j])
                    if cand:
                        return cand
    m = PLAKA_RE.search(full_text.replace("-", " ").upper())
    if m:
        return f"{m.group(1)} {m.group(2)} {m.group(3)}"
    return None

# ---------- Görsel OCR ----------
def extract_text_from_image_ocr(image_path: str) -> str:
    if pytesseract is None or Image is None:
        messagebox.showerror("OCR Hatası", "OCR için gerekli kütüphaneler kurulu değil (pytesseract, Pillow)")
        return ""
    try:
        image = Image.open(image_path)
        image = image.convert('L')
        return pytesseract.image_to_string(image, lang='tur+eng')
    except Exception as e:
        messagebox.showerror("OCR Hatası", f"Görsel işlenirken hata: {str(e)}")
        return ""

def parse_insurance_info_from_text(text: str) -> Dict[str, str]:
    info = {}
    lines = [line.strip() for line in text.split('\n') if line.strip()]

    # T.C. / VKN
    for i, line in enumerate(lines):
        if re.search(r'TC\s*[/]?\s*Vergi\s*No', line, re.IGNORECASE):
            nums = re.findall(r'\b\d{10,11}\b', line)
            if not nums and i+1 < len(lines):
                nums = re.findall(r'\b\d{10,11}\b', lines[i+1])
            if nums:
                info["T.C."] = nums[0]
            break
    if "T.C." not in info:
        m = re.search(r'\b\d{11}\b', text)
        if m: info["T.C."] = m.group(0)

    # Plaka
    for i, line in enumerate(lines):
        if re.search(r'\bPlaka\b', line, re.IGNORECASE):
            parts = re.split(r'Plaka\s*:?\s*', line, flags=re.IGNORECASE, maxsplit=1)
            if len(parts) > 1 and parts[1].strip():
                info["Plaka"] = _normalize_plate(parts[1].strip()); break
            if i+1 < len(lines):
                cand = _normalize_plate(lines[i+1])
                if re.match(r'\d{1,3}\s*[A-Z]', cand):
                    info["Plaka"] = cand; break
    if "Plaka" not in info:
        pm = PLAKA_RE.search(text.replace("-", " ").upper())
        if pm: info["Plaka"] = f"{pm.group(1)} {pm.group(2)} {pm.group(3)}"

    # Belge Seri No
    for i, line in enumerate(lines):
        if re.search(r'(Ruhsat|Belge)\s*Seri\s*No', line, re.IGNORECASE):
            sm = re.search(r'([A-Z0-9]{5,12})', line) or (re.search(r'([A-Z0-9]{5,12})', lines[i+1]) if i+1 < len(lines) else None)
            if sm: info["Belge Seri No"] = sm.group(1); break
    if "Belge Seri No" not in info:
        sm = re.search(r'\b([A-Z]{1,4}-?\d{4,8})\b', text)
        if sm: info["Belge Seri No"] = sm.group(1)

    # Doğum Tarihi
    for i, line in enumerate(lines):
        if re.search(r'Doğum\s*Tarihi', line, re.IGNORECASE):
            dm = re.search(r'(\d{1,2}\.\d{1,2}\.\d{4})', line) or (re.search(r'(\d{1,2}\.\d{1,2}\.\d{4})', lines[i+1]) if i+1 < len(lines) else None)
            if dm: info["Doğum Tarihi"] = dm.group(1); break
    if "Doğum Tarihi" not in info:
        dm = DATE_ANY.findall(text)
        for d in dm:
            nd = parse_date_any(d)
            if nd:
                try:
                    dt = datetime.datetime.strptime(nd, DATE_FMT).date()
                    if 1930 <= dt.year <= datetime.date.today().year:
                        info["Doğum Tarihi"] = nd
                        break
                except Exception:
                    pass

    # Ad Soyad
    for i, line in enumerate(lines):
        if re.search(r'(İsim|İsim\s*/\s*Soyisim|Ad\s*Soyad|Sigortal[ıi]|Sigorta\s*Ettiren)', line, re.IGNORECASE):
            for j in range(1, 10):
                if i + j < len(lines):
                    cand = lines[i + j].strip()
                    if _looks_like_name(cand):
                        info["Ad Soyad"] = _clean_name(cand); break
            if "Ad Soyad" in info: break
    if "Ad Soyad" not in info:
        for ln in lines:
            if _looks_like_name(ln):
                info["Ad Soyad"] = _clean_name(ln); break

    # UVAT/Adres Kodu
    for i, line in enumerate(lines):
        if re.search(r'Adres\s*Kodu|UVAT', line, re.IGNORECASE):
            m = re.search(r'(\d{6,12})', line) or (re.search(r'(\d{6,12})', lines[i+1]) if i+1 < len(lines) else None)
            if m: info["UVAT Kodu"] = m.group(1); break

    # Poliçe No
    for i, line in enumerate(lines):
        if re.search(r'Poliçe\s*No', line, re.IGNORECASE):
            pm = re.search(r'([A-Z0-9\-\/\.]{6,20})', line) or (re.search(r'([A-Z0-9\-\/\.]{6,20})', lines[i+1]) if i+1 < len(lines) else None)
            if pm: info["Poliçe No"] = pm.group(1); break

    # Başlangıç/Bitiş
    bas = _find_near_date(lines, BAS_HINT)
    bit = _find_near_date(lines, BITIS_HINT)
    cy = datetime.date.today().year
    if not (bas and bit):
        candidates = [parse_date_any(d) for d in DATE_ANY.findall(text)]
        filt = []
        for d in candidates:
            try:
                dt = datetime.datetime.strptime(d, DATE_FMT).date()
                if 2010 <= dt.year <= (cy + 1):
                    filt.append(d)
            except Exception:
                pass
        if len(filt) >= 2:
            d1 = datetime.datetime.strptime(filt[0], DATE_FMT)
            d2 = datetime.datetime.strptime(filt[1], DATE_FMT)
            bas = bas or (filt[0] if d1 <= d2 else filt[1])
            bit = bit or (filt[1] if d1 <= d2 else filt[0])

    if bas: info["Başlangıç"] = bas
    if bit: info["Bitiş"] = bit

    # Şirket
    for i, line in enumerate(lines):
        if re.search(r'Sigorta\s*Şirketi', line, re.IGNORECASE):
            parts = re.split(r'Sigorta\s*Şirketi\s*:?\s*', line, flags=re.IGNORECASE, maxsplit=1)
            if len(parts) > 1 and parts[1].strip():
                info["Şirket"] = parts[1].strip(); break
            if i+1 < len(lines) and lines[i+1].strip():
                info["Şirket"] = lines[i+1].strip(); break

    # Acente
    for i, line in enumerate(lines):
        if re.search(r'Acente\s*Kodu', line, re.IGNORECASE):
            am = re.search(r'(\d{4,8})', line) or (re.search(r'(\d{4,8})', lines[i+1]) if i+1 < len(lines) else None)
            if am: info["Acente"] = am.group(1); break

    return info

def process_image_from_clipboard():
    """Panodan görseli alır, OCR yapar, formu doldurur (WhatsApp Desktop kopyalanan görseller dahil)."""
    if Image is None or ImageGrab is None:
        messagebox.showerror("Hata", "Pillow (Image, ImageGrab) kütüphanesi gerekli.")
        return
    try:
        data = ImageGrab.grabclipboard()
        img = None
        if isinstance(data, Image.Image):
            img = data
        elif isinstance(data, list) and data and os.path.isfile(str(data[0])):
            # Bazı uygulamalar panoya dosya yolu listesi bırakır
            try:
                img = Image.open(data[0])
            except Exception:
                img = None
        if img is None:
            messagebox.showinfo("Bilgi", "Panoda görsel bulunamadı (WhatsApp’ta görüntüye sağ tık → Kopyala).")
            return

        temp_path = "_clipboard_image_tmp.png"
        img.save(temp_path, "PNG")

        text = extract_text_from_image_ocr(temp_path)
        if not text.strip():
            messagebox.showinfo("Bilgi", "Görselden metin çıkarılamadı.")
            try: os.remove(temp_path)
            except: pass
            return

        info = parse_insurance_info_from_text(text)

        if info:
            for key, value in info.items():
                if key in app.vars:
                    app.vars[key].set(value)
            app.on_baslangic_change()
            app.on_bitis_change()
            messagebox.showinfo("Başarılı", f"{len(info)} bilgi görselden alındı ve forma dolduruldu.")
            print("OCR metni:\n", text)
            print("Ayıklanan info:\n", info)
        else:
            messagebox.showinfo("Bilgi", "Görselden uygun bilgi çıkarılamadı.")

        try: os.remove(temp_path)
        except: pass

    except Exception as e:
        messagebox.showerror("Hata", f"Görsel işlenirken hata: {str(e)}")

# ---------- PDF okuma / ayrıştırma ----------
def extract_text_from_pdf_advanced(path: str) -> str:
    text = ""
    if fitz is not None:
        try:
            doc = fitz.open(path)
            text = "\n".join(p.get_text("text") or "" for p in doc)
        except Exception:
            text = ""
    if (not text or not text.strip()) and pdfplumber is not None:
        try:
            with pdfplumber.open(path) as pdf:
                text = "\n".join((p.extract_text() or "") for p in pdf.pages)
        except Exception:
            text = ""
    if (not text or not text.strip()) and PdfReader is not None:
        try:
            r = PdfReader(path)
            text = "\n".join((p.extract_text() or "") for p in r.pages)
        except Exception:
            text = ""
    if (not text or not text.strip()) and convert_from_path and pytesseract and Image:
        try:
            images = convert_from_path(path, dpi=300, first_page=1, last_page=2)
            text = "\n".join(pytesseract.image_to_string(im, lang="tur") for im in images)
        except Exception:
            text = ""
    return text or ""

def parse_pdf_fields_targeted(text: str) -> Dict[str, str]:
    out = {}
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]

    # Poliçe No
    for pat in POLNO_PATTERNS:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            out["Poliçe No"] = m.group(1).strip(" :-")
            break
    if "Poliçe No" not in out:
        for ln in lines:
            nk = _norm_key(ln)
            if ("pol" in nk and "no" in nk) or "poli" in nk:
                m = re.search(r"([A-Z0-9][A-Z0-9\-\/\.]{5,})", ln.upper())
                if m:
                    out["Poliçe No"] = m.group(1); break

    # Başlangıç / Bitiş
    bas = _find_near_date(lines, BAS_HINT)
    bit = _find_near_date(lines, BITIS_HINT)
    if not (bas and bit):
        cy = datetime.date.today().year
        candidates = [parse_date_any(d) for d in DATE_ANY.findall(text)]
        filt = []
        for d in candidates:
            try:
                dt = datetime.datetime.strptime(d, DATE_FMT).date()
                if 2010 <= dt.year <= (cy + 1): filt.append(d)
            except Exception:
                pass
        if len(filt) >= 2:
            d1 = datetime.datetime.strptime(filt[0], DATE_FMT)
            d2 = datetime.datetime.strptime(filt[1], DATE_FMT)
            bas = bas or (filt[0] if d1 <= d2 else filt[1])
            bit = bit or (filt[1] if d1 <= d2 else filt[0])
    if bas: out["Başlangıç"] = bas
    if bit: out["Bitiş"] = bit

    # Doğum Tarihi
    dt = _find_birth_date(lines)
    if dt: out["Doğum Tarihi"] = dt

    # Plaka
    pl = _find_plate(lines, text)
    if pl: out["Plaka"] = pl

    # Ad Soyad
    for i, ln in enumerate(lines):
        for rx in SIGORTALI_HINTS:
            m = rx.match(ln)
            if m:
                cand = m.group(1).strip()
                if _looks_like_name(cand):
                    out["Ad Soyad"] = _clean_name(cand); return out
                for j in (1, 2):
                    if i + j < len(lines):
                        cand2 = lines[i + j].strip()
                        if _looks_like_name(cand2):
                            out["Ad Soyad"] = _clean_name(cand2); return out
    for ln in lines:
        if _looks_like_name(ln):
            out.setdefault("Ad Soyad", _clean_name(ln)); break
    return out

# ---------- QR metni ----------
SERIAL_PATTERNS = [
    r"\bBelge\s*Seri\s*No\s*[:=]\s*([0-9A-Z\-]{3,})",
    r"\bBelge\s*Seri\s*[:=]\s*([0-9A-Z\-]{3,})",
    r"\bBelge\s*No\s*[:=]\s*([0-9A-Z\-]{3,})",
    r"\bSeri\s*No\s*[:=]\s*([0-9A-Z\-]{3,})",
    r"\bSeriNo\s*[:=]\s*([0-9A-Z\-]{3,})",
    r"\bBelgeSeriNo\s*[:=]\s*([0-9A-Z\-]{3,})",
]

def parse_qr_text_all(raw: str) -> Dict[str, str]:
    out = {}
    text = str(raw)
    flat = " ".join(text.split())

    # TC/VKN
    m = re.search(r"\b\d{11}\b", flat)
    if m:
        out["T.C."] = m.group(0)
    else:
        m = re.search(r"\b\d{10}\b", flat)
        if m: out["T.C."] = m.group(0)

    # Plaka
    pl = _normalize_plate(flat.replace("-", " "))
    if pl: out["Plaka"] = pl

    # Belge Seri
    for pat in SERIAL_PATTERNS:
        m = re.search(pat, flat, flags=re.IGNORECASE)
        if m:
            out["Belge Seri No"] = m.group(1).strip(); break
    if "Belge Seri No" not in out:
        m = re.search(r"\b([A-Z]{1,4}-?\d{4,8})\b", flat)
        if m: out["Belge Seri No"] = m.group(1)

    # Anahtar:Değer satırları
    lines = re.split(r"[\r\n;|]+", text)
    for ln in lines:
        if not ln.strip(): continue
        if ":" in ln or "=" in ln:
            parts = re.split(r"[:=]", ln, maxsplit=1)
            if len(parts) < 2: continue
            key, val = parts[0], parts[1].strip()
            nk = _norm_key(key); val = val.strip()
            if any(k in nk for k in ["ad soyad","adi soyadi","isim soyisim","isim","adi"]) and _looks_like_name(val):
                out["Ad Soyad"] = _clean_name(val); continue
            if "sigortali" in nk or "sigorta ettiren" in nk:
                if _looks_like_name(val): out["Ad Soyad"] = _clean_name(val); continue
            if any(k in nk for k in ["dogum tarihi","d t","dt"]):
                nd = parse_date_any(val)
                if nd: out["Doğum Tarihi"] = nd; continue
            if any(k in nk for k in ["baslangic","tanzim","duzenleme","bas tar","baslangi"]):
                nd = parse_date_any(val)
                if nd: out["Başlangıç"] = nd; continue
            if any(k in nk for k in ["bitis","vade sonu","vade bitis","son tarih"]):
                nd = parse_date_any(val)
                if nd: out["Bitiş"] = nd; continue
            if "plaka" in nk:
                pl2 = _normalize_plate(val)
                if pl2: out["Plaka"] = pl2; continue
            if "tc" in nk or "t c" in nk or "vkn" in nk or "vergi" in nk:
                m = re.search(r"\b\d{10,11}\b", val)
                if m: out["T.C."] = m.group(0); continue
            if "belge" in nk or "seri" in nk:
                m = re.search(r"[A-Z0-9\-]{3,}", val.strip().upper())
                if m: out["Belge Seri No"] = m.group(0); continue

    # Etiketsiz yedekler
    if "Ad Soyad" not in out:
        for ln in lines:
            if _looks_like_name(ln):
                out["Ad Soyad"] = _clean_name(ln); break

    cy = datetime.date.today().year
    all_dates = [parse_date_any(d) for d in DATE_ANY.findall(flat)]
    filt = []
    for d in all_dates:
        try:
            dt = datetime.datetime.strptime(d, DATE_FMT).date()
            if 2010 <= dt.year <= (cy + 1): filt.append(d)
        except Exception:
            pass
    if "Başlangıç" not in out or "Bitiş" not in out:
        if len(filt) >= 2:
            d1 = datetime.datetime.strptime(filt[0], DATE_FMT)
            d2 = datetime.datetime.strptime(filt[1], DATE_FMT)
            bas = filt[0] if d1 <= d2 else filt[1]
            bit = filt[1] if d1 <= d2 else filt[0]
            out.setdefault("Başlangıç", bas)
            out.setdefault("Bitiş", bit)
        elif len(filt) == 1:
            out.setdefault("Başlangıç", filt[0])

    return out

def decode_qr_from_image_path(path: str) -> Optional[str]:
    """Görsel dosyasından QR metnini çözer (pyzbar → opencv yedekli)."""
    if not (QR_PYZBAR or QR_CV):
        messagebox.showerror("QR Hatası", "QR kod okuyucu kütüphaneler kurulu değil.\nGereken: pyzbar veya opencv-python")
        return None

    try:
        if QR_PYZBAR and Image is not None:
            img = Image.open(path).convert("RGB")
            codes = qr_decode(img)
            if codes:
                qr_data = codes[0].data.decode("utf-8", errors="ignore")
                if qr_data.strip():
                    return qr_data

        if QR_CV:
            img_cv = cv2.imread(path)
            if img_cv is not None:
                detector = cv2.QRCodeDetector()
                qr_data, _, _ = detector.detectAndDecode(img_cv)
                if qr_data.strip():
                    return qr_data

    except Exception as e:
        messagebox.showerror("QR Okuma Hatası", f"Görselden QR kod okunurken hata oluştu:\n{e}")

    return None

# ---------- Undo/Redo destekli Entry ----------
def attach_undo(entry: ttk.Entry, var: tk.StringVar):
    entry._snapshot = var.get()
    entry._undo_stack = []
    entry._redo_stack = []

    def on_keyrelease(_):
        cur = var.get()
        if cur != entry._snapshot:
            entry._undo_stack.append(entry._snapshot)
            if len(entry._undo_stack) > 100:
                entry._undo_stack.pop(0)
            entry._snapshot = cur
            entry._redo_stack.clear()

    entry.bind("<KeyRelease>", on_keyrelease)
    def on_focusin(_): entry._snapshot = var.get()
    entry.bind("<FocusIn>", on_focusin)

    def do_undo(_=None):
        if entry._undo_stack:
            prev = entry._undo_stack.pop()
            entry._redo_stack.append(var.get())
            var.set(prev)
            entry._snapshot = prev
        return "break"

    def do_redo(_=None):
        if entry._redo_stack:
            nxt = entry._redo_stack.pop()
            entry._undo_stack.append(var.get())
            var.set(nxt)
            entry._snapshot = nxt
        return "break"

    entry.bind("<Control-z>", do_undo)
    entry.bind("<Control-y>", do_redo)

# -------------- Uygulama --------------
class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.rows = safe_load()
        self.selected_index = None
        self._last_table_rows = []
        ensure_dirs()

        # --- DEMO kontrolü ve güncelleme ---
        if is_demo_expired():
            self.disable_all_features()
            messagebox.showwarning("Demo Süresi Doldu", "7 günlük demo süresi sona erdi.\nLütfen tam sürüme geçin.")
        else:
            self.root.after(3000, check_for_update)

        # buradan sonra __init__ bitiyor (diğer kodlar devam ediyor)

    # <<< __init__ bitti, artık normal metodlar burada olacak >>>
    def disable_all_features(self):
        for child in self.root.winfo_children():
            self._disable_recursively(child)

    def _disable_recursively(self, widget):
        try:
            widget.configure(state="disabled")
        except:
            pass
        for child in widget.winfo_children():
            self._disable_recursively(child)


    # <<< BURADAN SONRA EKLE >>>
    def disable_all_features(self):
        for child in self.root.winfo_children():
            self._disable_recursively(child)

    def _disable_recursively(self, widget):
        try:
            widget.configure(state="disabled")
        except:
            pass
        for child in widget.winfo_children():
            self._disable_recursively(child)

# --- DEMO kontrolü ve güncelleme ---
        if is_demo_expired():
            self.disable_all_features()
            messagebox.showwarning("Demo Süresi Doldu", "7 günlük demo süresi sona erdi.\nLütfen tam sürüme geçin.")
        else:
            self.root.after(3000, check_for_update)

        try:
            import tkinter.font as tkfont
            tkfont.nametofont("TkDefaultFont").configure(family="Segoe UI", size=9)
            ttk.Style(self.root).theme_use("clam")
        except Exception:
            pass

        # Üst bar
        tb = tk.Frame(root)
        tb.pack(side="top", fill="x", padx=6, pady=4)
        self._btn(tb, "Güncelle", self.btn_update)
        self._btn(tb, "Sil", self.btn_delete)
        self._btn(tb, "Hepsini Sil", self.btn_delete_all)
        ttk.Separator(tb, orient="vertical").pack(side="left", fill="y", padx=6)
        self._btn(tb, "PDF Yükle", self.btn_pdf)
        self._btn(tb, "Poliçe Dosyası Ekle", self.btn_attach_file)
        self._btn(tb, "QR Kod Yapıştır (Görsel)", self.btn_qr_image_from_clipboard)  # değiştirildi
        self._btn(tb, "QR İçeriği Yapıştır", self.btn_qr_paste)
        self._btn(tb, "Görsel Yapıştır (OCR)", self.btn_paste_image)
        ttk.Separator(tb, orient="vertical").pack(side="left", fill="y", padx=6)
        self._btn(tb, "CSV Dışa Aktar", self.btn_export_csv)
        self._btn(tb, "Fiş (HTML)", self.btn_export_html)

        # Gövde
        body = tk.Frame(root)
        body.pack(side="top", fill="both", expand=True, padx=6, pady=(0, 6))

        # Sol form
        left = tk.Frame(body)
        left.pack(side="left", fill="y", padx=(0, 6))
        self.vars = {}
        self.entries = {}

        def row(i, label, key, width=26):
            tk.Label(left, text=label, anchor="w").grid(row=i, column=0, sticky="w", padx=(0, 4), pady=1)
            v = tk.StringVar()
            e = ttk.Entry(left, textvariable=v, width=width)
            e.grid(row=i, column=1, sticky="we", pady=1)
            attach_undo(e, v)
            self.vars[key] = v
            self.entries[key] = e

        left.grid_columnconfigure(1, weight=1)
        r = 0
        row(r, "Ad Soyad", "Ad Soyad"); r += 1
        row(r, "T.C.", "T.C."); r += 1
        row(r, "Doğum Tarihi (gg.aa.yyyy)", "Doğum Tarihi"); r += 1
        row(r, "Plaka", "Plaka"); r += 1
        row(r, "Belge Seri No", "Belge Seri No"); r += 1
        row(r, "UVAT Kodu", "UVAT Kodu"); r += 1
        tk.Label(left, text="Poliçe Türü").grid(row=r, column=0, sticky="w")
        self.cmb_tur = ttk.Combobox(left, values=POLICE_TURLERI, state="readonly", width=24)
        self.cmb_tur.grid(row=r, column=1, sticky="we", pady=1); r += 1
        row(r, "Poliçe No", "Poliçe No"); r += 1
        row(r, "Acente", "Acente"); r += 1
        row(r, "Şirket", "Şirket"); r += 1
        row(r, "Başlangıç (gg.aa.yyyy)", "Başlangıç"); r += 1
        row(r, "Bitiş (gg.aa.yyyy)", "Bitiş"); r += 1
        row(r, "Kalan Gün", "Kalan Gün"); r += 1
        row(r, "Poliçe Dosyası", "Poliçe Dosyası"); r += 1
        btns = tk.Frame(left)
        btns.grid(row=r, column=0, columnspan=2, sticky="we", pady=(6, 0))
        ttk.Button(btns, text="Kaydet", command=self.btn_save).pack(side="left", fill="x", expand=True)
        ttk.Button(btns, text="Temizle", command=self.clear_form).pack(side="left", fill="x", expand=True)
        r += 1

        self.entries["Başlangıç"].bind("<FocusOut>", self.on_baslangic_change)
        self.entries["Bitiş"].bind("<FocusOut>", self.on_bitis_change)

        # Sağ tablo
        right = tk.Frame(body)
        right.pack(side="right", fill="both", expand=True)
        sb = tk.Frame(right)
        sb.pack(side="top", fill="x", pady=(0, 4))
        tk.Label(sb, text="Ara:").pack(side="left")
        self.var_search = tk.StringVar()
        ent_search = ttk.Entry(sb, textvariable=self.var_search)
        ent_search.pack(side="left", fill="x", expand=True, padx=6)
        ent_search.bind("<KeyRelease>", lambda _e: self.refresh_table())
        ent_search.bind("<Return>", lambda _e: self.refresh_table())
        self._btn(sb, "Filtrele", self.refresh_table)
        self._btn(sb, "Filtreyi Temizle", self.clear_filter)

        wrap = tk.Frame(right)
        wrap.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(wrap, columns=DISPLAY_COLS, show="headings")
        vs = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        hs = ttk.Scrollbar(wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=vs.set, xscroll=hs.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)
        for f in DISPLAY_COLS:
            self.tree.heading(f, text=f)
            self.tree.column(f, width=COL_WIDTHS.get(f, 120), anchor="center")
        self.tree.tag_configure("tomato", background="tomato")
        self.tree.tag_configure("khaki", background="khaki")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<Button-1>", self._copy_cell_event)
        self.tree.bind("<ButtonRelease-1>", self._copy_cell_event)

        self.root.geometry("1366x760+80+40")
        self.refresh_table()

    # UI helper
    def _btn(self, parent, text, cmd):
        b = ttk.Button(parent, text=text, command=cmd)
        b.pack(side="left", padx=2)
        return b

    # Görsel yapıştır (OCR)
    def btn_paste_image(self):
        process_image_from_clipboard()

    # *** QR kodu panodan görsel olarak oku (WhatsApp kopyalanan görsel) ***
    def btn_qr_image_from_clipboard(self):
        if Image is None or ImageGrab is None:
            messagebox.showerror("Hata", "Pillow (Image, ImageGrab) kütüphanesi gerekli.")
            return
        try:
            data = ImageGrab.grabclipboard()
            img = None
            if isinstance(data, Image.Image):
                img = data
            elif isinstance(data, list) and data and os.path.isfile(str(data[0])):
                try:
                    img = Image.open(data[0])
                except Exception:
                    img = None
            if img is None:
                messagebox.showinfo("QR", "Panoda görsel bulunamadı (WhatsApp’ta görüntüye sağ tık → Kopyala).")
                return

            tf = "_qr_clip_tmp.png"
            img.save(tf, "PNG")
            try:
                txt = decode_qr_from_image_path(tf)
            finally:
                try: os.remove(tf)
                except: pass

            if not txt:
                messagebox.showinfo("QR", "Panodan gelen görselde QR bulunamadı/okunamadı.")
                return

            self._apply_qr_text(txt)

        except Exception as e:
            messagebox.showerror("Hata", f"QR görseli okunurken hata: {str(e)}")

    def _apply_qr_text(self, raw: str):
        f = parse_qr_text_all(raw)
        for key in ("Plaka", "T.C.", "Belge Seri No", "Ad Soyad", "Doğum Tarihi", "Başlangıç", "Bitiş"):
            if f.get(key):
                self.vars[key].set(f[key])
        self.update_kalan_gun_field()
        if not any(f.get(k) for k in f):
            messagebox.showinfo("QR", "Metinden uygun bilgi çıkarılamadı.")

    def btn_qr_paste(self):
        try:
            raw = self.root.clipboard_get()
        except Exception:
            raw = ""
        if not raw:
            messagebox.showinfo("QR", "Panoda metin yok.")
            return
        self._apply_qr_text(raw)

    # Hücre tıklanınca kopyala
    def _copy_cell_event(self, event):
        rowid = self.tree.identify_row(event.y)
        colid = self.tree.identify_column(event.x)
        if not rowid or not colid or colid == "#0":
            return
        idx = int(colid[1:]) - 1
        if idx < 0 or idx >= len(DISPLAY_COLS):
            return
        try:
            val = self.tree.set(rowid, DISPLAY_COLS[idx])
        except Exception:
            return
        val = str(val).strip()
        if not val:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(val)
        self.root.title(f"{APP_TITLE}  |  Kopyalandı: {DISPLAY_COLS[idx]} = {val}")

    # Hesaplama
    def on_baslangic_change(self, _=None):
        bas = self.vars["Başlangıç"].get().strip()
        if bas:
            nd = parse_date_any(bas)
            if nd:
                self.vars["Başlangıç"].set(nd)
            bit = add_365(self.vars["Başlangıç"].get().strip())
            if bit:
                self.vars["Bitiş"].set(bit)
        self.update_kalan_gun_field()

    def on_bitis_change(self, _=None):
        bit = self.vars["Bitiş"].get().strip()
        nd = parse_date_any(bit)
        if nd:
            self.vars["Bitiş"].set(nd)
        self.update_kalan_gun_field()

    def update_kalan_gun_field(self):
        kg = kalan_gun(self.vars["Bitiş"].get().strip())
        self.vars["Kalan Gün"].set("" if kg is None else str(kg))

    # Form topla
    def collect_fields(self):
        rec = {k: self.vars.get(k).get().strip() for k in self.vars}
        rec["Poliçe Türü"] = self.cmb_tur.get().strip()
        if rec.get("Başlangıç") and not rec.get("Bitiş"):
            rec["Bitiş"] = add_365(rec["Başlangıç"])
        kg = kalan_gun(rec.get("Bitiş", ""))
        rec["Kalan Gün"] = "" if kg is None else str(kg)
        return rec

    # Butonlar
    def btn_save(self):
        rec = self.collect_fields()
        self.rows.append(rec)
        safe_save(self.rows)
        self.refresh_table()
        self.clear_form()

    def btn_update(self):
        if self.selected_index is None:
            messagebox.showinfo("Güncelle", "Tablodan bir kayıt seçin.")
            return
        rec = self.collect_fields()
        pdos = rec.get("Poliçe Dosyası", "")
        if pdos and os.path.isfile(pdos) and not pdos.startswith(POLICE_DIR):
            newp = copy_policy_file(pdos, rec)
            if newp:
                rec["Poliçe Dosyası"] = newp
        self.rows[self.selected_index] = rec
        safe_save(self.rows)
        self.refresh_table()

    def btn_delete(self):
        if self.selected_index is None:
            messagebox.showinfo("Sil", "Tablodan bir kayıt seçin.")
            return
        del self.rows[self.selected_index]
        safe_save(self.rows)
        self.refresh_table()
        self.clear_form()

    def btn_delete_all(self):
        if messagebox.askyesno("Hepsini Sil", "Tüm kayıtlar silinsin mi?"):
            self.rows = []
            safe_save(self.rows)
            self.refresh_table()
            self.clear_form()

    def btn_export_csv(self):
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")], title="CSV kaydet")
        if not p:
            return
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=[c for c in DISPLAY_COLS if c != "No"])
            w.writeheader()
            for r in self.rows:
                row_out = {k: r.get(k, "") for k in DISPLAY_COLS if k not in ("No",)}
                w.writerow(row_out)
        messagebox.showinfo("CSV", "Dışa aktarıldı.")

    def btn_export_html(self):
        if self.selected_index is None:
            messagebox.showinfo("Fiş", "Tablodan bir kayıt seçin.")
            return
        r = self.rows[self.selected_index]
        p = filedialog.asksaveasfilename(defaultextension=".html", filetypes=[("HTML", "*.html")], title="Kayıt fişi kaydet")
        if not p:
            return
        with open(p, "w", encoding="utf-8") as f:
            def row(k):
                return f"<tr><th style='text-align:left;padding:6px;background:#f5f5f5'>{k}</th><td style='padding:6px'>{r.get(k, '')}</td></tr>"
            cols = [c for c in DISPLAY_COLS if c != "No"]
            rows_html = "\n".join(row(k) for k in cols)
            now = datetime.datetime.now().strftime("%d.%m.%Y %H:%M")
            f.write(f"<!doctype html><meta charset='utf-8'><title>Poliçe Fişi</title>"
                    f"<style>body{{font-family:Arial;margin:24px}}table{{border-collapse:collapse;width:100%}}"
                    f"th,td{{border:1px solid #ddd}}</style>"
                    f"<h1>Poliçe Bilgisi</h1><div>{now}</div><table>{rows_html}</table>")
        webbrowser.open(f"file://{os.path.abspath(p)}")

    def btn_attach_file(self):
        p = filedialog.askopenfilename(title="Poliçe PDF seç", filetypes=[("PDF", "*.pdf"), ("Tümü", "*.*")])
        if not p:
            return
        self.vars["Poliçe Dosyası"].set(p)

    def btn_pdf(self):
        p = filedialog.askopenfilename(title="Poliçe PDF seç", filetypes=[("PDF", "*.pdf"), ("Tümü", "*.*")])
        if not p:
            return

        text = extract_text_from_pdf_advanced(p)
        if not text.strip():
            messagebox.showinfo("PDF", "Metin çıkarılamadı (görsel olabilir).")

        f = parse_pdf_fields_targeted(text)
        for k in ("Ad Soyad", "Poliçe No", "Başlangıç", "Bitiş", "Doğum Tarihi", "Plaka"):
            if f.get(k):
                self.vars[k].set(f[k])

        self.on_baslangic_change()

        qr_raw = decode_qr_from_pdf_first_page(p)
        if qr_raw:
            qrf = parse_qr_text_all(qr_raw)
            for key in ("Plaka", "Belge Seri No", "T.C.", "Ad Soyad"):
                if qrf.get(key) and not self.vars[key].get().strip():
                    self.vars[key].set(qrf[key])

        fake = {k: self.vars.get(k, tk.StringVar(value="")).get() for k in FIELDS}
        newp = copy_policy_file(p, fake)
        self.vars["Poliçe Dosyası"].set(newp or p)

    # Tablo & Form
    def clear_form(self):
        for k in self.vars:
            self.vars[k].set("")
        self.cmb_tur.set("")
        self.selected_index = None
        self.update_kalan_gun_field()

    def _filtered_rows(self):
        q = self.var_search.get().strip().lower()
        if not q:
            return self.rows
        out = []
        for r in self.rows:
            blob = " ".join(str(r.get(k, '')) for k in DISPLAY_COLS if k != 'No')
            if q in blob.lower():
                out.append(r)
        return out

    def _sort_by_kalan_gun(self, rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
        def kgval(r):
            kg = kalan_gun(r.get("Bitiş", ""))
            return 10 ** 9 if kg is None else kg
        return sorted(rows, key=kgval)

    def refresh_table(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        fl = self._filtered_rows()
        rows_sorted = self._sort_by_kalan_gun(fl)
        self._last_table_rows = rows_sorted
        for idx, r in enumerate(rows_sorted, start=1):
            kg = kalan_gun(r.get("Bitiş", ""))
            r["Kalan Gün"] = "" if kg is None else str(kg)
            tag = renk_kodu(kg)
            row_values = [idx] + [r.get(k, "") for k in DISPLAY_COLS if k not in ("No",)]
            self.tree.insert("", "end", values=row_values, tags=(tag,))
        safe_save(self.rows)
        self.root.title(f"{APP_TITLE}  |  Toplam kayıt: {len(self.rows)}")

    def clear_filter(self):
        self.var_search.set("")
        self.refresh_table()

    def on_select(self, _=None):
        sel = self.tree.selection()
        if not sel:
            self.selected_index = None
            return
        idx = self.tree.index(sel[0])
        if idx < 0 or idx >= len(self._last_table_rows):
            return
        rec = self._last_table_rows[idx]
        # self.rows içinde gerçek indeksi bul
        for i, row in enumerate(self.rows):
            if row == rec:
                self.selected_index = i
                break
        for k in self.vars:
            self.vars[k].set(rec.get(k, ""))
        self.cmb_tur.set(rec.get("Poliçe Türü", ""))
        self.update_kalan_gun_field()

    def on_double_click(self, _=None):
        sel = self.tree.selection()
        if not sel:
            return
        idx = self.tree.index(sel[0])
        if idx < 0 or idx >= len(self._last_table_rows):
            return
        p = self._last_table_rows[idx].get("Poliçe Dosyası", "")
        if p and os.path.isfile(p):
            webbrowser.open(f"file://{os.path.abspath(p)}")

# main
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
