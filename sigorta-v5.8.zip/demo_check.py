# demo_check.py
import os
import datetime
from tkinter import messagebox

DEMO_FILE = "demo_start.txt"
DEMO_LIMIT_DAYS = 7

def is_demo_expired():
    try:
        if not os.path.exists(DEMO_FILE):
            with open(DEMO_FILE, "w") as f:
                f.write(datetime.date.today().isoformat())
            return False
        with open(DEMO_FILE, "r") as f:
            start_date = datetime.date.fromisoformat(f.read().strip())
        days_passed = (datetime.date.today() - start_date).days
        return days_passed >= DEMO_LIMIT_DAYS
    except Exception:
        return True  # Güvenlik: hata varsa demo sona ermiş say
