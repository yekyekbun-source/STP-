import os, zipfile, io, sys, subprocess
import requests
from tkinter import messagebox

UPDATE_CHECK_URL = "https://raw.githubusercontent.com/kullaniciadi/sigorta-tracker/main/version.txt"
UPDATE_ZIP_URL = "https://github.com/kullaniciadi/sigorta-tracker/raw/main/sigorta-v5.8.zip"
CURRENT_VERSION = "5.7"

def check_for_update():
    try:
        r = requests.get(UPDATE_CHECK_URL, timeout=5)
        latest = r.text.strip()
        if latest > CURRENT_VERSION:
            if messagebox.askyesno("Güncelleme", f"Yeni sürüm var: v{latest}\nGüncellemek ister misiniz?"):
                return download_and_apply_update()
    except Exception as e:
        messagebox.showerror("Güncelleme Hatası", f"Güncelleme kontrol edilemedi:\n{e}")

def download_and_apply_update():
    try:
        r = requests.get(UPDATE_ZIP_URL, timeout=10)
        z = zipfile.ZipFile(io.BytesIO(r.content))
        z.extractall("update_temp")
        for name in z.namelist():
            src = os.path.join("update_temp", name)
            dst = name
            if os.path.isfile(src):
                os.replace(src, dst)
        subprocess.Popen([sys.executable] + sys.argv)
        sys.exit()
    except Exception as e:
        messagebox.showerror("Güncelleme Hatası", f"Güncelleme uygulanamadı:\n{e}")
